export HISTFILE=/tmp/.busybox_ash_history

