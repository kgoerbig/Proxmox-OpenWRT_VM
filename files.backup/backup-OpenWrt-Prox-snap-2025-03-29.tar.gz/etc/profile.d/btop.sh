alias btop="btop --utf-force"
